# BonusAtlas – Casino Bonus Scraper

## 1. Overview
A small pipeline that fetches a permitted public page, finds the promotional text for **three** casinos, uses a **language model (OpenAI API)** to turn that free text into structured fields, validates the result, saves it to `casinos.json`, and shows it on a responsive static website.

## 2. Problem statement
Promotional terms are written as free text and differ per casino. This project extracts three comparable fields (welcome bonus, wagering requirement, minimum deposit) without inventing values the source does not state.

## 3. Features
- robots.txt check, descriptive User-Agent, 15 s timeouts, HTTP/network error handling
- Real LLM step (official `openai` SDK, JSON-mode output) with strict validation
- Anti-hallucination guard: numbers in a field must appear in the source passage, otherwise the field becomes `null`
- Failed scrapes never overwrite good data; atomic file writes
- Responsive dark-navy/mint site: summary, search, table (cards on mobile), loading/error/empty states, refresh button
- 30 offline unit tests (mocked HTTP and mocked LLM), including regression tests for two matching bugs found in review

## 4. Architecture
`robots.txt check → fetch page → extract text → find each casino's passage → LLM → validate → write casinos.json → index.html reads casinos.json`
The website is static and only displays the JSON. It never runs the scraper and holds no secrets.

## 5. Project structure
```
index.html  styles.css  script.js     website
scraper.py                            scraper + LLM + validation
casinos.json                          data (starts empty)
requirements.txt  .env.example  .gitignore  LICENSE
tests/test_parser.py  tests/test_output.py
production-plan.md  AI_REFLECTION.md
```

## 6. Technologies
Python 3.10+, requests, BeautifulSoup4, OpenAI Python SDK, python-dotenv, HTML5/CSS3/vanilla JS, unittest.

## 7. Prerequisites
Python 3.10 or newer, an OpenAI API key, and a public page you are allowed to scrape.

## 8. Installation
```
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 9. Environment configuration
```
cp .env.example .env             # Windows: copy .env.example .env
```
Edit `.env`: `OPENAI_API_KEY`, optionally `OPENAI_MODEL`, plus `SOURCE_URL` and `CASINO_NAMES` (exactly three, as written on the page). `.env` is git-ignored; never commit it or paste the key into code, screenshots or chat.

**Choosing a source:** I could not verify any source's terms from my environment, so no source is pre-selected. Pick a public page (ideally an official promotions page or one whose terms allow automated access), read its terms, and check `https://<host>/robots.txt` yourself. The scraper also refuses to run if robots.txt disallows the page or can't be read.

## 10. Run the scraper
```
python scraper.py
```
Or without `.env`: `python scraper.py --source-url "https://…" --casinos "A,B,C"`.
Exit codes: `0` all three complete, `2` written but some records incomplete, `1` failure (existing `casinos.json` left untouched).

## 11. View the website
`fetch()` does not work from `file://`, so serve the folder:
```
python -m http.server 8000
```
Open `http://localhost:8000`. With the initial empty `casinos.json` you will see the "No verified records yet" state.

## 12. Run the tests
```
python -m unittest discover -s tests -t . -v
```
Expected: `Ran 30 tests ... OK`.
(`pip install pytest && python -m pytest` also works.) Tests need no network or API key.

## 13. Deploy (GitHub Pages)
1. Create a free GitHub account and a new **public** repository (e.g. `casino-bonus-scraper`).
2. Push the project:
```
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<you>/casino-bonus-scraper.git
git push -u origin main
```
(On a phone you can instead use the GitHub web page → **Add file → Upload files**.) Check `.env` is **not** uploaded.
3. Repository **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: `main` / `/ (root)` → Save**.
4. After about a minute the page shows your URL: `https://<you>.github.io/casino-bonus-scraper/`.
5. Open it and confirm the table or empty state appears (not the red error box). Upload an updated `casinos.json` after each scrape.
Static hosting only serves files: it cannot run Python or hold API keys.

## 14. Data schema (`casinos.json`)
| Field | Meaning |
|---|---|
| `last_updated` | ISO 8601 UTC time of the last successful write, or `null` |
| `source_url` | Page the data came from |
| `notes` | Dataset-level message |
| `casinos[].casino_name` | Name as supplied |
| `casinos[].welcome_bonus` / `wagering_requirement` / `minimum_deposit` | String, or `null` if not stated/unsupported |
| `casinos[].source_url` | Traceable source for that record |
| `casinos[].extraction_status` | `complete`, `partial`, `not_found` (name not on page), `failed` (model/API error) |
| `casinos[].notes` | Why a value was dropped or an error occurred |

## 15. Attribution and scraping limits
Record every source you use. Only public, permitted pages; no login, CAPTCHA or anti-bot bypass; one page fetch per run. Passage matching is by name, so a page where names appear in unusual layouts may yield `not_found` or `partial`.

## 16. Security
No keys in code or frontend; `.env` ignored; scraped text rendered with `textContent`; external links use `rel="noopener noreferrer"`; JSON validated before writing.

## 17. Known limitations
- No live scrape or live OpenAI call has been run against a real source; the pipeline was exercised end to end only against a local test page with a stubbed LLM.
- `wagering_requirement` is stored as a string like `35x` (or `No wagering`), not a bare number.
- Wagering text like `100x20 spins` would be read as `100x`; the number guard catches invented numbers but not every ambiguous phrasing. Always eyeball the JSON against the source page.
- Website not tested in a real browser (JS syntax checked only).
- No JavaScript rendering support (static HTML pages only).
- Terms may be misread by the model; always check the operator's site.

## 18. Future improvements
Scheduled runs (GitHub Actions), per-source parsers, retries/backoff, history of changes, a database (see `production-plan.md`).

## 19. Common errors
- `OPENAI_API_KEY is not set` → create `.env` from `.env.example`.
- `robots.txt disallows…` → choose another permitted source.
- `Exactly 3 casino names are required` → check `CASINO_NAMES`.
- Site shows "Could not load casinos.json" → serve via `python -m http.server`, don't double-click the file.
